import React, { Component } from 'react'



/**
 * 
 */
 class Footer extends Component {
  render() {
    return (
      <div>
           <footer className="App-footer">
           © COPYRIGHT 2018 ALL RIGHTS RESERVED.    |    SYNERGISTICIT   | SITEMAP.
        </footer>
      </div>
    )
  }
}
export default Footer;